# CheckRel - Website Relevance Checker

A Chrome extension that checks if a website is relevant based on predefined keywords.

## Features

- Simple popup interface with a "Check Relevance" button
- Compares keywords against website title, URL, description, and contents
- Configurable keywords via the keywords.json file

## Installation

1. Clone or download this repository to your computer
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" using the toggle in the top-right corner
4. Click "Load unpacked" and select the directory containing this extension
5. The extension should now be installed and visible in your toolbar

## Usage

1. Navigate to any website you want to check
2. Click the CheckRel extension icon in your toolbar
3. Click "Check Relevance" to analyze the current page
4. The extension will display whether the page is relevant to your keywords

## Customizing Keywords

You can customize the keyword list by editing the `keywords.json` file in the extension directory:

1. Open `keywords.json` in a text editor
2. Modify the keywords array with your preferred keywords
3. Save the file
4. Reload the extension in Chrome by going to `chrome://extensions/` and clicking the refresh icon on the extension card

## How It Works

The extension compares keywords against different parts of the webpage with varying weights:
- Title (highest weight): 4 points per keyword match
- URL: 3 points per keyword match
- Meta Description: 2 points per keyword match
- Page Content: 1 point per keyword match

A total score of 5 or higher classifies the page as relevant.

## License

This project is open-source. 