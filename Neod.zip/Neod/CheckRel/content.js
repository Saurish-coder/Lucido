// Set up a flag to indicate this content script is loaded
window.checkRelExtensionLoaded = true;

// Listen for messages from the popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Content script received message:', message);

  if (message.action === 'ping') {
    // Respond to ping to verify connection
    console.log('Received ping, sending pong');
    sendResponse({ status: 'connected' });
    return true;
  }
  
  if (message.action === 'checkRelevance') {
    try {
      console.log('Checking page relevance with keywords:', message.keywords);
      const result = checkPageRelevance(message.keywords);
      console.log('Relevance result:', result);
      sendResponse(result);
    } catch (error) {
      console.error('Error checking relevance:', error);
      sendResponse({ error: error.message });
    }
    return true; // Indicates async response
  }
});

// Log that content script has been loaded
console.log('CheckRel content script loaded and ready');

/**
 * Check if the page is relevant based on keywords
 * @param {string[]} keywords - Keywords to check against
 * @returns {{relevant: boolean, relevanceLevel: string, score: number, matches: Object}}
 */
function checkPageRelevance(keywords) {
  // Get the page content
  const title = document.title.toLowerCase();
  const url = window.location.href.toLowerCase();
  const metaDescription = getMetaDescription().toLowerCase();
  const bodyText = document.body.innerText.toLowerCase();
  
  // Store matches for each section
  const matches = {
    title: [],
    url: [],
    description: [],
    content: []
  };
  
  // Check for keyword matches
  keywords.forEach(keyword => {
    const lowerKeyword = keyword.toLowerCase();
    
    // Check title (high importance)
    if (title.includes(lowerKeyword)) {
      matches.title.push(keyword);
    }
    
    // Check URL (high importance)
    if (url.includes(lowerKeyword)) {
      matches.url.push(keyword);
    }
    
    // Check meta description (medium importance)
    if (metaDescription && metaDescription.includes(lowerKeyword)) {
      matches.description.push(keyword);
    }
    
    // Check body text (lower importance)
    if (bodyText.includes(lowerKeyword)) {
      matches.content.push(keyword);
    }
  });
  
  // Calculate relevance score
  // Weights: Title (4), URL (3), Description (2), Content (1)
  const score = 
    matches.title.length * 4 + 
    matches.url.length * 3 + 
    matches.description.length * 2 + 
    matches.content.length * 1;
  
  // Determine relevance level with much higher thresholds
  let relevanceLevel = "not relevant";
  let relevant = false;
  
  if (score >= 75) {
    relevanceLevel = "highly relevant";
    relevant = true;
  } else if (score >= 40) {
    relevanceLevel = "moderately relevant";
    relevant = true;
  } else {
    relevanceLevel = "not relevant";
    relevant = false;
  }
  
  return {
    relevant,
    relevanceLevel,
    score,
    matches
  };
}

/**
 * Gets the meta description of the page
 * @returns {string} The meta description or empty string
 */
function getMetaDescription() {
  const metaDescription = document.querySelector('meta[name="description"]');
  return metaDescription ? metaDescription.getAttribute('content') : '';
} 