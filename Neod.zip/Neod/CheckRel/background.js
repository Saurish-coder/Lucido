// Background script for the CheckRel extension
chrome.runtime.onInstalled.addListener(() => {
  console.log('CheckRel extension has been installed');
});

// Keep track of tabs we've injected the content script into
const injectedTabs = new Set();

// Listen for when a tab is updated to ensure content script is properly injected
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && !injectedTabs.has(tabId)) {
    // Check if this is a chrome:// or other restricted URL
    if (tab.url && !isRestrictedUrl(tab.url)) {
      // Only inject if we haven't already done so for this tab and it's not a restricted URL
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ['content.js']
      })
      .then(() => {
        // Mark this tab as injected
        injectedTabs.add(tabId);
        console.log(`Content script injected into tab ${tabId}`);
      })
      .catch(error => {
        // Don't log errors for restricted URLs
        if (!isErrorFromRestrictedUrl(error.message)) {
          console.error(`Error injecting content script into tab ${tabId}:`, error);
        }
      });
    }
  }
});

// Clean up injectedTabs set when tabs are closed
chrome.tabs.onRemoved.addListener((tabId) => {
  injectedTabs.delete(tabId);
});

/**
 * Check if the URL is restricted (chrome://, extension://, etc.)
 * @param {string} url - The URL to check
 * @returns {boolean} True if the URL is restricted
 */
function isRestrictedUrl(url) {
  return url.startsWith('chrome://') || 
         url.startsWith('chrome-extension://') || 
         url.startsWith('chrome-search://') || 
         url.startsWith('devtools://') ||
         url.startsWith('view-source://') ||
         url.startsWith('about:') ||
         url.startsWith('data:') ||
         url.startsWith('file:///') ||
         url === 'about:blank';
}

/**
 * Check if an error message is related to a restricted URL
 * @param {string} errorMessage - The error message to check
 * @returns {boolean} True if the error is related to a restricted URL
 */
function isErrorFromRestrictedUrl(errorMessage) {
  return errorMessage.includes('Cannot access') || 
         errorMessage.includes('chrome://') || 
         errorMessage.includes('chrome-extension://') ||
         errorMessage.includes('Cannot establish connection');
} 