document.addEventListener('DOMContentLoaded', () => {
  const checkButton = document.getElementById('check-relevance');
  const resultDiv = document.getElementById('result');
  const loadingDiv = document.getElementById('loading');

  checkButton.addEventListener('click', async () => {
    resultDiv.style.display = 'none';
    loadingDiv.style.display = 'block';
    
    try {
      // Get the current active tab
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      // Check if this is a chrome:// URL (we can't inject scripts there)
      if (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://') || 
          tab.url.startsWith('chrome-search://') || tab.url.startsWith('devtools://')) {
        throw new Error('Cannot analyze Chrome internal pages. Please navigate to a regular website.');
      }
      
      // First check if we can establish connection with the content script
      try {
        await verifyContentScriptConnection(tab.id);
      } catch (error) {
        // If connection fails, try injecting the content script
        console.log('Connection failed, attempting to inject content script...');
        try {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['content.js']
          });
          console.log('Content script injection successful');
          
          // Wait a bit for the script to initialize
          await new Promise(resolve => setTimeout(resolve, 500));
          
          // Try to verify connection again
          await verifyContentScriptConnection(tab.id);
        } catch (injectionError) {
          if (injectionError.message.includes('Cannot access')) {
            throw new Error('Cannot analyze this page. Please try a regular website.');
          } else {
            throw new Error(`Failed to analyze page: ${injectionError.message}`);
          }
        }
      }
      
      // Fetch keywords from keywords.json
      const response = await fetch(chrome.runtime.getURL('keywords.json'));
      if (!response.ok) {
        throw new Error(`Failed to load keywords: ${response.status} ${response.statusText}`);
      }
      
      const keywordsData = await response.json();
      const keywords = keywordsData.keywords;
      
      // Check the website relevance
      const relevanceResult = await checkWebsiteRelevance(tab.id, keywords);
      
      // Display result with the new relevance levels
      resultDiv.innerHTML = '';
      const resultText = document.createElement('div');
      
      if (relevanceResult.relevant) {
        if (relevanceResult.relevanceLevel === 'highly relevant') {
          resultText.textContent = 'This website is highly relevant!';
          resultDiv.className = 'highly-relevant';
        } else {
          resultText.textContent = 'This website is moderately relevant';
          resultDiv.className = 'moderately-relevant';
        }
      } else {
        resultText.textContent = 'This website is not relevant';
        resultDiv.className = 'not-relevant';
      }
      
      resultDiv.appendChild(resultText);
      
      // Add score information
      const scoreDiv = document.createElement('div');
      scoreDiv.className = 'score';
      scoreDiv.textContent = `Score: ${relevanceResult.score.toFixed(0)}`;
      resultDiv.appendChild(scoreDiv);

      // Add match information
      if (relevanceResult.score > 0) {
        const matchesDiv = document.createElement('div');
        matchesDiv.className = 'matches';
        matchesDiv.style.fontSize = '0.8em';
        matchesDiv.style.marginTop = '8px';
        matchesDiv.style.textAlign = 'left';
        
        let matchesText = '<strong>Matched in:</strong><br>';
        if (relevanceResult.matches.title.length > 0) {
          matchesText += `• Title: ${relevanceResult.matches.title.length} keywords<br>`;
        }
        if (relevanceResult.matches.url.length > 0) {
          matchesText += `• URL: ${relevanceResult.matches.url.length} keywords<br>`;
        }
        if (relevanceResult.matches.description.length > 0) {
          matchesText += `• Description: ${relevanceResult.matches.description.length} keywords<br>`;
        }
        if (relevanceResult.matches.content.length > 0) {
          matchesText += `• Content: ${relevanceResult.matches.content.length} keywords<br>`;
        }
        
        matchesDiv.innerHTML = matchesText;
        resultDiv.appendChild(matchesDiv);
      }
      
      resultDiv.style.display = 'block';
    } catch (error) {
      console.error('Error:', error);
      resultDiv.innerHTML = '';
      resultDiv.className = 'error-message';
      
      // Handle common errors with more user-friendly messages
      if (error.message.includes('Cannot access') || 
          error.message.includes('chrome://') || 
          error.message.includes('internal page')) {
        resultDiv.textContent = 'Cannot analyze Chrome internal pages. Please navigate to a regular website.';
      } else if (error.message.includes('connection')) {
        resultDiv.textContent = 'Connection failed. Please reload the extension or try another page.';
      } else {
        resultDiv.textContent = `Error: ${error.message}`;
      }
      
      resultDiv.style.display = 'block';
    } finally {
      loadingDiv.style.display = 'none';
    }
  });
  
  /**
   * Verify that the content script is loaded and responsive
   * @param {number} tabId - Tab ID to check
   * @returns {Promise<boolean>}
   */
  async function verifyContentScriptConnection(tabId) {
    return new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(
        tabId,
        { action: 'ping' },
        response => {
          if (chrome.runtime.lastError) {
            reject(new Error(`Connection failed: ${chrome.runtime.lastError.message}`));
          } else if (response && response.status === 'connected') {
            console.log('Connection with content script verified');
            resolve(true);
          } else {
            reject(new Error('Invalid response from content script'));
          }
        }
      );
    });
  }
  
  /**
   * Checks website relevance against provided keywords
   * @param {number} tabId - Tab ID to check
   * @param {string[]} keywords - Keywords to check against
   * @returns {Promise<{relevant: boolean, relevanceLevel: string, score: number}>}
   */
  async function checkWebsiteRelevance(tabId, keywords) {
    return new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(
        tabId,
        {
          action: 'checkRelevance',
          keywords: keywords
        },
        response => {
          if (chrome.runtime.lastError) {
            reject(new Error(`Failed to check relevance: ${chrome.runtime.lastError.message}`));
          } else if (response && response.error) {
            reject(new Error(`Content script error: ${response.error}`));
          } else if (response) {
            resolve(response);
          } else {
            reject(new Error('No response from content script'));
          }
        }
      );
    });
  }
}); 