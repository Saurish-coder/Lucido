// Get UI elements
const toggle = document.getElementById('toggle');
const status = document.getElementById('status');

// Function to update the UI based on ad blocker status
function updateUI(enabled) {
  toggle.checked = enabled;
  
  if (enabled) {
    status.textContent = 'Ad Blocker is ENABLED';
    status.className = 'status enabled';
  } else {
    status.textContent = 'Ad Blocker is DISABLED';
    status.className = 'status disabled';
  }
}

// Load the current state from storage when the popup opens
chrome.storage.local.get('enabled', (data) => {
  // Default to enabled if not set
  const enabled = data.enabled !== undefined ? data.enabled : true;
  updateUI(enabled);
});

// Toggle the ad blocker when the switch is clicked
toggle.addEventListener('change', () => {
  const enabled = toggle.checked;
  
  // Save the new state to storage
  chrome.storage.local.set({ enabled: enabled });
  
  // Update the UI
  updateUI(enabled);
  
  // Refresh the current tab to apply/remove ad blocking
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.reload(tabs[0].id);
    }
  });
}); 