// Common ad-related class names and IDs
const adSelectors = [
  // Classes
  '.ad', '.ads', '.adsbygoogle', '.advert', '.advertisement', '.banner-ads', 
  '.sponsored', '.advertising', '.ad-container', '.ad-wrapper', '.ad-zone',
  '.ad-placement', '.ad-banner', '.ad-leaderboard', '.adsbox', '.adunit',
  '.banner_ad', '.skycraper-ad', '.ad-module', '.advert-container',
  // IDs
  '#ad', '#ads', '#adContainer', '#adWrapper', '#banner-ad', '#sponsored-content',
  '#advertisement', '#googlead', '#adsense', '#adunit', '#ad-placement',
  // Attributes
  '[data-ad]', '[data-ad-unit]', '[data-adunit]', '[data-ad-slot]', 
  '[class*="ad-"]', '[class*="ad_"]', '[class*="adv-"]', '[class*="adv_"]',
  '[id*="ad-"]', '[id*="ad_"]', '[id*="adv-"]', '[id*="adv_"]',
  // iframes
  'iframe[src*="ad"]', 'iframe[src*="ads"]', 'iframe[src*="doubleclick"]',
  'iframe[src*="googlesyndication"]', 'iframe[data-ad]'
];

// State to track if ad blocking is enabled
let adBlockingEnabled = true;

// Function to remove ad elements
function removeAds() {
  if (!adBlockingEnabled) return;
  
  // Use combined selector for better performance
  const allAds = document.querySelectorAll(adSelectors.join(','));
  
  allAds.forEach(ad => {
    ad.style.display = 'none';
    console.log('Ad blocked:', ad);
  });
}

// Function to create and add CSS to hide ads
function injectBlockingCSS() {
  if (!adBlockingEnabled) return;
  
  const style = document.createElement('style');
  style.id = 'simple-ad-blocker-styles';
  
  // Create CSS rules from selectors
  const cssRules = adSelectors.map(selector => `${selector} { display: none !important; }`).join('\n');
  
  style.textContent = cssRules;
  document.head.appendChild(style);
}

// Initialize: Check storage for enabled status
chrome.storage.local.get('enabled', (data) => {
  adBlockingEnabled = data.enabled !== undefined ? data.enabled : true;
  if (adBlockingEnabled) {
    init();
  }
});

// Listen for messages from background script
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === 'updateState') {
    adBlockingEnabled = message.enabled;
    
    // If enabled, run ad blocking
    if (adBlockingEnabled) {
      const existingStyle = document.getElementById('simple-ad-blocker-styles');
      if (!existingStyle) {
        injectBlockingCSS();
      }
      removeAds();
    } else {
      // If disabled, remove our CSS
      const existingStyle = document.getElementById('simple-ad-blocker-styles');
      if (existingStyle) {
        existingStyle.remove();
      }
    }
  }
});

// Initialize ad blocking
function init() {
  // Add CSS immediately to block ads as soon as possible
  injectBlockingCSS();
  
  // Remove ads that are currently on the page
  removeAds();
  
  // Set up a mutation observer to catch dynamically loaded ads
  const observer = new MutationObserver((mutations) => {
    if (adBlockingEnabled) {
      removeAds();
    }
  });
  
  // Start observing the document with the configured parameters
  observer.observe(document.body, { 
    childList: true, 
    subtree: true 
  });
}

// If document is already loaded, initialize immediately
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    if (adBlockingEnabled) init();
  });
} else {
  if (adBlockingEnabled) init();
} 