// List of common ad domains and patterns
const adDomains = [
  "doubleclick.net",
  "googleadservices.com",
  "googlesyndication.com",
  "adservice.google",
  "adform.net",
  "adnxs.com",
  "taboola.com",
  "outbrain.com",
  "amazon-adsystem.com",
  "scorecardresearch.com",
  "advertising.com"
];

// Ad URL patterns
const adPatterns = [
  "*://*.doubleclick.net/*",
  "*://partner.googleadservices.com/*",
  "*://*.googlesyndication.com/*",
  "*://googleads.g.doubleclick.net/*",
  "*://*.adform.net/*",
  "*://*.adnxs.com/*",
  "*://*.taboola.com/*",
  "*://*.outbrain.com/*",
  "*://*.amazon-adsystem.com/*",
  "*://*.scorecardresearch.com/*",
  "*://*.advertising.com/*",
  "*://adservice.google.com/*",
  "*://pagead2.googlesyndication.com/*",
  "*://tpc.googlesyndication.com/*",
  "*://ad.doubleclick.net/*",
  "*://securepubads.g.doubleclick.net/*"
];

// Common ad keywords in URLs
const adKeywords = [
  "ad", "ads", "advert", "advertisement", "banner", "sponsor", 
  "iframe", "googlead", "adsense", "adserv", "doubleclick", "trackad",
  "affiliate", "promotion", "pop", "popunder", "popup"
];

// Initialize ad blocking status in storage
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ enabled: true });
  console.log("Ad blocker installed and enabled by default");
});

// Listen for changes to the blocking status
chrome.storage.onChanged.addListener((changes) => {
  if (changes.enabled) {
    console.log(`Ad blocking ${changes.enabled.newValue ? 'enabled' : 'disabled'}`);
  }
});

// Chrome Manifest V3 uses declarativeNetRequest instead of webRequest with blocking
// For demonstration, we're using a content script approach for ad blocking
// Note: For complete ad blocking, actual extensions use more comprehensive lists like EasyList

// Send message to content script when ad blocker state changes
chrome.storage.onChanged.addListener((changes) => {
  if (changes.enabled) {
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, { 
          action: "updateState", 
          enabled: changes.enabled.newValue 
        }).catch(() => {
          // Tab might not have content script loaded yet, which is okay
        });
      });
    });
  }
}); 