# Simple Ad Blocker

A lightweight Chrome extension that blocks common ads on websites.

## Features

- Blocks ads from major ad networks
- Uses CSS and DOM manipulation to hide ad elements
- Simple on/off toggle via popup interface
- Minimal permissions required

## Installation

1. Download or clone this repository to your local machine
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" using the toggle in the top-right corner
4. Click "Load unpacked" and select the directory containing this extension
5. The extension is now installed and active

## Usage

- Click the extension icon in your Chrome toolbar to open the popup
- Use the toggle switch to enable or disable ad blocking
- Changes apply immediately after reloading the current page

## Technical Details

The extension works by:
1. Identifying common ad patterns, elements, and domains
2. Using CSS to hide ad elements via content scripts
3. Dynamically removing ad elements as they appear using MutationObserver

## Notes

- For production use, you would need to convert the SVG icons to PNG files
- This is a basic implementation - professional ad blockers use more comprehensive filter lists
- The extension currently does not use the declarativeNetRequest API, which would be recommended for production
- For a real extension, you should also implement a more robust filter system or use existing filter lists

## License

MIT License

## Privacy

This extension does not collect any data, track users, or communicate with external servers. 